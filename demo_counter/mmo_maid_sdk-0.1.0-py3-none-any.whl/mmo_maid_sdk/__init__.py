"""
MMO Maid Plugin SDK
===================

Write a plugin in three steps:

    from mmo_maid_sdk import Plugin, Context

    plugin = Plugin()

    @plugin.on_ready
    def ready(ctx: Context):
        ctx.log("My plugin is alive!")

    @plugin.on_event("message_create")
    def on_message(ctx: Context, event: dict):
        if "!hello" in event.get("content", ""):
            ctx.discord.send_message(
                channel_id=event["channel_id"],
                content="Hello from my plugin! 👋",
            )

    plugin.run()

That's it. The SDK handles the JSON-RPC wire protocol, event acking,
boot handshake, and error recovery so you don't have to.
"""

from mmo_maid_sdk._plugin import Plugin
from mmo_maid_sdk._context import Context
from mmo_maid_sdk._exceptions import CapabilityError, SdkError

__all__ = ["Plugin", "Context", "CapabilityError", "SdkError"]
__version__ = "0.1.0"
