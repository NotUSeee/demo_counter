"""
Plugin — the main class developers instantiate in their __main__.py.
"""
from __future__ import annotations

import os
import sys
import threading
from typing import Any, Callable, Dict, List, Optional

from mmo_maid_sdk._transport import Transport
from mmo_maid_sdk._context import Context


class Plugin:
    """
    The entry point for every MMO Maid plugin.

    Basic usage::

        from mmo_maid_sdk import Plugin, Context

        plugin = Plugin()

        @plugin.on_ready
        def ready(ctx: Context):
            ctx.log("Plugin started!")

        @plugin.on_event("message_create")
        def on_message(ctx: Context, event: dict):
            content = event.get("content", "")
            if "!ping" in content:
                ctx.discord.send_message(
                    channel_id=event["channel_id"],
                    content="Pong! 🏓",
                )

        plugin.run()  # must be last line of __main__.py
    """

    def __init__(self) -> None:
        self._transport = Transport()
        self._event_handlers: Dict[str, List[Callable]] = {}
        self._ready_handlers: List[Callable] = []
        self._ctx: Optional[Context] = None

        # Wire up internal host notifications
        self._transport.register_handler("host.boot", self._handle_boot)
        self._transport.register_handler("host.shutdown", self._handle_shutdown)

    # ── Decorators ─────────────────────────────────────────────────────────

    def on_ready(self, fn: Callable) -> Callable:
        """
        Register a function called once when the plugin boots successfully.

        The function receives one argument: ctx (Context).

        Example::

            @plugin.on_ready
            def started(ctx):
                ctx.log("Ready! Loaded config from KV.")
                config = ctx.kv.get("config") or {}
        """
        self._ready_handlers.append(fn)
        return fn

    def on_event(self, event_type: str) -> Callable:
        """
        Register a handler for a Discord event type.

        The function receives two arguments: ctx (Context) and event (dict).
        The event dict contents depend on the event type — see docs.

        Supported event types:
          - message_create      A message was sent in a channel
          - member_join         A member joined the server
          - member_leave        A member left the server
          - reaction_add        A reaction was added to a message
          - voice_state_update  A member's voice state changed

        Example::

            @plugin.on_event("member_join")
            def welcome(ctx: Context, event: dict):
                # event keys: user_id, username, guild_id
                ctx.log(f"New member: {event.get('username')}")
        """
        def decorator(fn: Callable) -> Callable:
            self._event_handlers.setdefault(event_type, []).append(fn)
            return fn
        return decorator

    # ── Internal boot handling ─────────────────────────────────────────────

    def _handle_boot(self, params: dict) -> None:
        """Called when the host sends host.boot — sets up the context."""
        self._ctx = Context(
            server_id=str(params.get("discord_srv_id") or ""),
            plugin_id=str(params.get("plugin_id") or ""),
            version=str(params.get("version") or ""),
            capabilities=list(params.get("capabilities") or []),
            transport=self._transport,
        )

        # Register event routing now that we have context
        for event_type in self._event_handlers:
            method = f"event.{event_type}"
            # capture event_type in closure
            def make_handler(et):
                def handler(params: dict):
                    self._dispatch_event(et, params)
                return handler
            self._transport.register_handler(method, make_handler(event_type))

        # Fire on_ready handlers in a thread so boot doesn't block the read loop
        if self._ready_handlers:
            def run_ready():
                for fn in self._ready_handlers:
                    try:
                        fn(self._ctx)
                    except Exception as e:
                        try:
                            self._ctx.log(f"on_ready error: {e}", level="error")
                        except Exception:
                            pass
            threading.Thread(target=run_ready, daemon=True).start()

    def _handle_shutdown(self, params: dict) -> None:
        sys.exit(0)

    def _dispatch_event(self, event_type: str, params: dict) -> None:
        """Route an incoming event to registered handlers then auto-ack it."""
        if self._ctx is None:
            return

        event_id = params.get("event_id")
        event = params.get("event") or {}

        handlers = self._event_handlers.get(event_type, [])
        for fn in handlers:
            try:
                fn(self._ctx, event)
            except Exception as e:
                try:
                    self._ctx.log(
                        f"Event handler error ({event_type}): {e}",
                        level="error",
                    )
                except Exception:
                    pass

        # Auto-ack so the runner marks the event as delivered
        if event_id is not None:
            try:
                self._transport.call("event.ack", {"event_id": event_id})
            except Exception:
                pass

    # ── Main run loop ──────────────────────────────────────────────────────

    def run(self) -> None:
        """
        Start the plugin.  This call blocks forever.

        Must be the last line of your __main__.py.
        """
        # Unbuffer stdout so JSON-RPC lines flush immediately
        sys.stdout = open(sys.stdout.fileno(), "w", buffering=1, closefd=False)  # noqa: WPS515

        # Ping the host so it knows we started cleanly
        self._transport.notify("plugin.log", {
            "level": "info",
            "message": "SDK plugin process started",
        })

        # Block reading stdin until the host closes it
        try:
            self._transport.read_loop()
        except KeyboardInterrupt:
            pass
