"""
Context — the object your event handlers receive.

Every handler gets a Context that exposes:
  - ctx.log(message)              print to plugin audit log
  - ctx.kv.get/set/delete         per-server key-value storage
  - ctx.discord.send_message      send Discord messages
  - ctx.http.get/post/request     make HTTP requests (approved domains only)
  - ctx.server_id                 the Discord server ID this install is for
  - ctx.plugin_id                 your plugin's ID
"""
from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from mmo_maid_sdk._transport import Transport


class _KvApi:
    """ctx.kv — key-value storage (requires storage:kv capability)."""

    def __init__(self, transport: "Transport") -> None:
        self._t = transport

    def get(self, key: str) -> Any:
        """
        Get a value by key.  Returns the stored value, or None if not set.

        Example::

            count = ctx.kv.get("message_count") or 0
        """
        result = self._t.call("kv.get", {"key": str(key)})
        if isinstance(result, dict) and "value" in result:
            v = result["value"]
            if isinstance(v, dict) and "value_json" in v:
                return v["value_json"]
            return v
        return None

    def set(self, key: str, value: Any) -> None:
        """
        Store a value.  Value must be JSON-serialisable.

        Example::

            ctx.kv.set("message_count", count + 1)
        """
        self._t.call("kv.put", {"key": str(key), "value": value})

    def delete(self, key: str) -> None:
        """Delete a key (no-op if it doesn't exist)."""
        self._t.call("kv.del", {"key": str(key)})


class _DiscordApi:
    """ctx.discord — Discord actions (require specific capabilities)."""

    def __init__(self, transport: "Transport") -> None:
        self._t = transport

    def send_message(self, *, channel_id: str, content: str) -> None:
        """
        Send a message to a Discord channel.

        Requires capability: discord:send_message

        Example::

            ctx.discord.send_message(
                channel_id=event["channel_id"],
                content="Hello! 👋",
            )
        """
        self._t.call("discord.send_message", {
            "channel_id": str(channel_id),
            "content": str(content),
        })


class _HttpApi:
    """ctx.http — outbound HTTP requests (requires proxy:http capability)."""

    def __init__(self, transport: "Transport") -> None:
        self._t = transport

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request through the sandbox proxy.

        Only domains approved during plugin installation are reachable.
        Raises CapabilityError if proxy:http is not approved.
        Raises RuntimeError if the domain is not on the approved list.

        Returns dict with keys: status (int), headers (dict), body (str), truncated (bool)

        Example::

            resp = ctx.http.request("GET", "https://api.example.com/data")
            data = json.loads(resp["body"])
        """
        result = self._t.call("proxy.request", {
            "method": method.upper(),
            "url": url,
            "headers": headers or {},
            "body": body,
        })
        return result or {}

    def get(self, url: str, *, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Convenience wrapper for GET requests."""
        return self.request("GET", url, headers=headers)

    def post(
        self,
        url: str,
        *,
        body: str,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Convenience wrapper for POST requests."""
        return self.request("POST", url, headers=headers, body=body)


class Context:
    """
    The context object passed to every event handler.

    Attributes:
        server_id   Discord server (guild) ID as a string
        plugin_id   Your plugin's ID string
        version     Installed version string
        kv          Key-value storage API
        discord     Discord actions API
        http        HTTP proxy API
    """

    def __init__(
        self,
        *,
        server_id: str,
        plugin_id: str,
        version: str,
        capabilities: list,
        transport: "Transport",
    ) -> None:
        self.server_id = server_id
        self.plugin_id = plugin_id
        self.version = version
        self.capabilities = set(capabilities or [])
        self._transport = transport

        self.kv      = _KvApi(transport)
        self.discord = _DiscordApi(transport)
        self.http    = _HttpApi(transport)

    def log(self, message: str, *, level: str = "info") -> None:
        """
        Write a message to the plugin audit log.

        Visible to server admins in the MMO Maid dashboard.
        Level can be "info", "warn", or "error".

        Example::

            ctx.log("Processing event...")
            ctx.log("Something went wrong", level="error")
        """
        self._transport.notify("plugin.log", {
            "level": str(level),
            "message": str(message)[:4000],
        })

    def has_capability(self, cap: str) -> bool:
        """Check if this install has a specific capability approved."""
        return cap in self.capabilities
