"""
Low-level JSON-RPC transport over stdin/stdout.

This is internal — plugin developers should use Plugin and Context instead.
"""
from __future__ import annotations

import json
import sys
import threading
from typing import Any, Callable, Dict, Optional


class Transport:
    """
    Thread-safe JSON-RPC transport over stdin/stdout.

    The host (plugin runner) sends requests and notifications on stdin.
    We respond on stdout.  All lines are newline-delimited JSON.
    """

    def __init__(self) -> None:
        self._write_lock = threading.Lock()
        self._pending: Dict[int, threading.Event] = {}
        self._results: Dict[int, Any] = {}
        self._errors: Dict[int, str] = {}
        self._next_id = 1
        self._next_id_lock = threading.Lock()
        # Registered notification handlers: method -> callable
        self._handlers: Dict[str, Callable] = {}

    # ── Writing ────────────────────────────────────────────────────────────

    def _write(self, obj: Dict[str, Any]) -> None:
        line = json.dumps(obj, separators=(",", ":"))
        with self._write_lock:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()

    def _next_req_id(self) -> int:
        with self._next_id_lock:
            rid = self._next_id
            self._next_id += 1
        return rid

    # ── RPC calls (plugin → host) ──────────────────────────────────────────

    def call(self, method: str, params: Dict[str, Any]) -> Any:
        """
        Send a request to the host and block until the response arrives.
        Raises RuntimeError on RPC error, CapabilityError on capability denial.
        """
        from mmo_maid_sdk._exceptions import CapabilityError

        rid = self._next_req_id()
        evt = threading.Event()
        self._pending[rid] = evt

        self._write({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})

        # Block — the reader thread will set the event when the response arrives
        evt.wait(timeout=30)

        if rid in self._errors:
            err = self._errors.pop(rid, "unknown error")
            if "capability" in err.lower():
                raise CapabilityError(err)
            raise RuntimeError(f"RPC error ({method}): {err}")

        return self._results.pop(rid, None)

    def notify(self, method: str, params: Dict[str, Any]) -> None:
        """Send a notification to the host (no response expected)."""
        self._write({"jsonrpc": "2.0", "method": method, "params": params})

    # ── Reading ────────────────────────────────────────────────────────────

    def register_handler(self, method: str, fn: Callable) -> None:
        self._handlers[method] = fn

    def read_loop(self) -> None:
        """
        Run forever reading stdin.  Dispatches:
          - Responses (has "id" + "result"/"error") → unblock pending call()
          - Notifications (has "method", no "id") → call registered handler
        Exits when stdin closes (host shut down the plugin).
        """
        for line in sys.stdin:
            s = line.strip()
            if not s:
                continue
            try:
                msg = json.loads(s)
            except json.JSONDecodeError:
                continue

            if not isinstance(msg, dict):
                continue

            msg_id = msg.get("id")
            method = msg.get("method")

            # ── Response to one of our calls ──────────────────────────────
            if msg_id is not None and msg_id in self._pending:
                if "error" in msg:
                    err = msg["error"]
                    self._errors[msg_id] = (
                        err.get("message") if isinstance(err, dict) else str(err)
                    )
                else:
                    self._results[msg_id] = msg.get("result")
                self._pending[msg_id].set()
                continue

            # ── Notification from host (event, boot, etc.) ─────────────────
            if method and msg_id is None:
                handler = self._handlers.get(method)
                if handler:
                    try:
                        handler(msg.get("params") or {})
                    except Exception as e:
                        # Never crash the read loop — log and continue
                        try:
                            self.notify("plugin.log", {
                                "level": "error",
                                "message": f"Handler error for {method}: {e}",
                            })
                        except Exception:
                            pass
