class SdkError(Exception):
    """Base class for all SDK errors."""


class CapabilityError(SdkError):
    """Raised when a plugin calls an API it doesn't have capability for."""
