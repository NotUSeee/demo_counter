"""
Plugin — the main class developers instantiate in their __main__.py.

Fixes applied:
  F35: _dispatch_event only auto-acks if all handlers completed without exception.
       On any exception, the event is left pending for the runner to reclaim.
  F38: In pool mode, context is rebuilt per event from the event params so
       ctx.server_id and ctx.has_capability() are correct for each delivery.
"""
from __future__ import annotations

import os
import sys
import threading
from typing import Any, Callable, Dict, List, Optional

from ._transport import Transport
from ._context import Context


class Plugin:
    """
    The entry point for every MMO Maid plugin.

    Basic usage::

        from mmo_maid_sdk import Plugin, Context

        plugin = Plugin()

        @plugin.on_ready
        def ready(ctx: Context):
            ctx.log("Plugin started!")

        @plugin.on_event("message_create")
        def on_message(ctx: Context, event: dict):
            content = event.get("content", "")
            if "!ping" in content:
                ctx.discord.send_message(
                    channel_id=event["channel_id"],
                    content="Pong! 🏓",
                )

        plugin.run()  # must be last line of __main__.py
    """

    def __init__(self) -> None:
        self._transport = Transport()
        self._event_handlers: Dict[str, List[Callable]] = {}
        self._ready_handlers: List[Callable] = []
        self._dashboard_handlers: Dict[str, Callable] = {}  # method_name → handler
        self._scheduled_tasks: List[tuple] = []  # (fn, interval_seconds)
        self._scheduled_threads: List[threading.Thread] = []
        self._lifecycle_handlers: Dict[str, Callable] = {}  # "install"/"enable"/"disable"/"uninstall" → fn
        self._ctx: Optional[Context] = None
        # F38: track whether we're in pool mode
        self._pool_mode: bool = False
        # Batch ack buffer — flushed as a single non-blocking notification.
        # Protected by lock for thread-safety with multiple dispatch threads.
        self._ack_buffer: List[str] = []
        self._ack_lock = threading.Lock()
        self._ACK_FLUSH_SIZE = 1
        self._stop_event = threading.Event()

        # Wire up internal host notifications
        self._transport.register_handler("host.boot", self._handle_boot)
        self._transport.register_handler("host.shutdown", self._handle_shutdown)
        self._transport.register_handler("host.install", self._handle_lifecycle)
        self._transport.register_handler("host.enable", self._handle_lifecycle)
        self._transport.register_handler("host.disable", self._handle_lifecycle)
        self._transport.register_handler("host.uninstall", self._handle_lifecycle)
        # Flush ack buffer when dispatch queue drains
        self._transport._on_queue_idle = self._flush_ack_buffer

    # ── Decorators ─────────────────────────────────────────────────────────

    def on_ready(self, fn: Callable) -> Callable:
        """
        Register a function called once when the plugin boots successfully.

        The function receives one argument: ctx (Context).
        """
        self._ready_handlers.append(fn)
        return fn

    def on_event(self, event_type: str) -> Callable:
        """
        Register a handler for a Discord event type.

        The function receives two arguments: ctx (Context) and event (dict).

        Supported event types:
          - message_create        A message was sent in a channel
          - message_edit          A message was edited
          - message_delete        A message was deleted
          - member_join           A member joined the server
          - member_leave          A member left the server
          - member_update         A member's roles/nick/avatar changed
          - reaction_add          A reaction was added to a message
          - reaction_remove       A reaction was removed from a message
          - voice_state_update    A member's voice state changed
          - interaction_create    A slash command, button, select, or modal was used
          - channel_create        A channel was created
          - channel_delete        A channel was deleted
          - channel_update        A channel was modified
          - role_create           A role was created
          - role_delete           A role was deleted
          - role_update           A role was modified
        """
        def decorator(fn: Callable) -> Callable:
            self._event_handlers.setdefault(event_type, []).append(fn)
            return fn
        return decorator

    def on_slash_command(self, command_name: str) -> Callable:
        """Register a handler for a specific slash command.

        Convenience wrapper that filters interaction_create events.
        The function receives two arguments: ctx (Context) and event (dict).

        Example::

            @plugin.on_slash_command("hello")
            def handle_hello(ctx, event):
                ctx.interaction.respond(content="Hello!")
        """
        def decorator(fn: Callable) -> Callable:
            def filtered_handler(ctx, event):
                if (event.get("interaction_type") == 2  # APPLICATION_COMMAND
                        and event.get("command_name") == command_name):
                    return fn(ctx, event)
            self._event_handlers.setdefault("interaction_create", []).append(filtered_handler)
            return fn
        return decorator

    def on_component(self, custom_id: str) -> Callable:
        """Register a handler for a component interaction (button click, select, etc.).

        Convenience wrapper that filters interaction_create events by custom_id.
        The function receives two arguments: ctx (Context) and event (dict).

        Example::

            @plugin.on_component("btn_join")
            def handle_join(ctx, event):
                ctx.interaction.respond(content="You joined!", ephemeral=True)
        """
        def decorator(fn: Callable) -> Callable:
            def filtered_handler(ctx, event):
                if (event.get("interaction_type") == 3  # MESSAGE_COMPONENT
                        and event.get("custom_id") == custom_id):
                    return fn(ctx, event)
            self._event_handlers.setdefault("interaction_create", []).append(filtered_handler)
            return fn
        return decorator

    def on_modal_submit(self, custom_id: str) -> Callable:
        """Register a handler for a modal form submission.

        Convenience wrapper that filters interaction_create events.
        The function receives two arguments: ctx (Context) and event (dict).
        ``event["modal_values"]`` contains {custom_id: value} for each field.

        Example::

            @plugin.on_modal_submit("signup_form")
            def handle_signup(ctx, event):
                name = event["modal_values"].get("char_name", "")
                ctx.interaction.respond(content=f"Welcome, {name}!")
        """
        def decorator(fn: Callable) -> Callable:
            def filtered_handler(ctx, event):
                if (event.get("interaction_type") == 5  # MODAL_SUBMIT
                        and event.get("custom_id") == custom_id):
                    return fn(ctx, event)
            self._event_handlers.setdefault("interaction_create", []).append(filtered_handler)
            return fn
        return decorator

    def schedule(self, interval_seconds: int) -> Callable:
        """Register a background task that runs on a fixed interval.

        The function receives one argument: ctx (Context).
        Starts after on_ready completes. Stops when the plugin shuts down.

        Example::

            @plugin.schedule(300)  # every 5 minutes
            def cleanup(ctx):
                ctx.log("Running cleanup...")
                # do work
        """
        def decorator(fn: Callable) -> Callable:
            self._scheduled_tasks.append((fn, int(interval_seconds)))
            return fn
        return decorator

    def on_dashboard(self, method_name: str) -> Callable:
        """Register a dashboard data handler for the manifest-based dashboard.

        The platform calls these when a user views the plugin's dashboard page.
        The function receives (ctx, params) and returns a JSON-serializable dict.

        Widget types and expected return formats:
          stat_card  → {"value": 1234, "change": "+12%"}
          chart      → {"labels": [...], "series": [{"name": "...", "data": [...]}]}
          table      → {"rows": [{...}, ...], "total": 100}
          form (get) → {"values": {"key": "value", ...}}
          form (save)→ {"ok": True}

        Example::

            @plugin.on_dashboard("get_stat")
            def handle_get_stat(ctx, params):
                total = ctx.kv.get("total_events") or 0
                return {"value": int(total)}

            @plugin.on_dashboard("get_timeseries")
            def handle_get_timeseries(ctx, params):
                period = params.get("period", "7d")
                data = ctx.kv.get(f"timeseries:{period}") or {}
                return {"labels": data.get("labels", []), "series": data.get("series", [])}
        """
        def decorator(fn: Callable) -> Callable:
            self._dashboard_handlers[str(method_name)] = fn
            return fn
        return decorator

    # ── Lifecycle hooks ────────────────────────────────────────────────────

    def on_install(self, fn: Callable) -> Callable:
        """Called once when the plugin is first installed on a server.

        Use this to initialize default settings in KV storage.
        The function receives one argument: ctx (Context).
        """
        self._lifecycle_handlers["install"] = fn
        return fn

    def on_enable(self, fn: Callable) -> Callable:
        """Called when the plugin is enabled (toggled on) for a server.

        The function receives one argument: ctx (Context).
        """
        self._lifecycle_handlers["enable"] = fn
        return fn

    def on_disable(self, fn: Callable) -> Callable:
        """Called when the plugin is disabled (toggled off) for a server.

        Use this to pause background work or save state.
        The function receives one argument: ctx (Context).
        """
        self._lifecycle_handlers["disable"] = fn
        return fn

    def on_uninstall(self, fn: Callable) -> Callable:
        """Called when the plugin is being uninstalled from a server.

        Use this to clean up KV data or log a final message.
        The function receives one argument: ctx (Context).
        """
        self._lifecycle_handlers["uninstall"] = fn
        return fn

    # ── Internal boot handling ─────────────────────────────────────────────

    def _handle_boot(self, params: dict) -> None:
        """Called when the host sends host.boot — sets up the base context."""
        self._pool_mode = (params.get("mode") == "pool")

        self._ctx = Context(
            server_id=str(params.get("discord_srv_id") or ""),
            plugin_id=str(params.get("plugin_id") or ""),
            version=str(params.get("version") or ""),
            capabilities=list(params.get("capabilities") or []),
            transport=self._transport,
        )

        # Register event routing now that we have context
        for event_type in self._event_handlers:
            method = f"event.{event_type}"
            def make_handler(et):
                def handler(params: dict):
                    self._dispatch_event(et, params)
                return handler
            self._transport.register_handler(method, make_handler(event_type))

        # Register dashboard data handlers (request-response pattern)
        # Platform sends "dashboard.{method_name}" with an "id" field,
        # expecting a JSON-RPC response with the widget data.
        for method_name, handler_fn in self._dashboard_handlers.items():
            rpc_method = f"dashboard.{method_name}"
            def make_dash_handler(fn):
                def dash_handler(params: dict):
                    # Build a per-request context with the server ID from params
                    ctx = Context(
                        server_id=str(params.get("discord_srv_id") or self._ctx.server_id),
                        plugin_id=str(self._ctx.plugin_id),
                        version=str(self._ctx.version),
                        capabilities=list(self._ctx.capabilities),
                        transport=self._transport,
                    )
                    try:
                        result = fn(ctx, params)
                        return result  # Transport sends this as the response
                    except Exception as e:
                        ctx.log(f"Dashboard handler error ({method_name}): {e}", level="error")
                        return {"error": str(e)}
                return dash_handler
            self._transport.register_handler(rpc_method, make_dash_handler(handler_fn))

        # Fire on_ready handlers in a thread so boot doesn't block the read loop
        if (self._ready_handlers or self._scheduled_tasks) and not self._pool_mode:
            def run_ready():
                for fn in self._ready_handlers:
                    try:
                        fn(self._ctx)
                    except Exception as e:
                        try:
                            self._ctx.log(f"on_ready error: {e}", level="error")
                        except Exception:
                            pass
                # Start scheduled background tasks after on_ready
                for task_fn, interval in self._scheduled_tasks:
                    self._start_scheduled_task(task_fn, interval)
            threading.Thread(target=run_ready, daemon=True).start()

    def _start_scheduled_task(self, fn: Callable, interval: int) -> None:
        """Start a daemon thread that calls fn(ctx) every interval seconds."""
        def loop():
            while not self._stop_event.is_set():
                self._stop_event.wait(interval)
                if self._stop_event.is_set():
                    break
                try:
                    fn(self._ctx)
                except Exception as e:
                    try:
                        self._ctx.log(f"Scheduled task error: {e}", level="error")
                    except Exception:
                        pass
        t = threading.Thread(target=loop, daemon=True, name=f"sched-{fn.__name__}")
        t.start()
        self._scheduled_threads.append(t)

    def _handle_lifecycle(self, params: dict) -> None:
        """Handle host.install, host.enable, host.disable, host.uninstall."""
        if self._ctx is None:
            return
        lifecycle_type = str(params.get("lifecycle") or params.get("type") or "")
        handler = self._lifecycle_handlers.get(lifecycle_type)
        if handler:
            try:
                handler(self._ctx)
            except Exception as e:
                try:
                    self._ctx.log(f"Lifecycle handler error ({lifecycle_type}): {e}", level="error")
                except Exception:
                    pass

    def _handle_shutdown(self, params: dict) -> None:
        self._stop_event.set()  # Signal scheduled tasks to stop
        sys.exit(0)

    def _dispatch_event(self, event_type: str, params: dict) -> None:
        """Route an incoming event to registered handlers.

        F35: Only auto-acks if ALL handlers completed without exception.
             On any exception, the event is left pending for runner reclaim.
        F38: In pool mode, build a per-event context from the params so
             ctx.server_id and ctx.has_capability() reflect the actual
             delivery — not the blank values from host.boot.
        """
        if self._ctx is None:
            return

        event_id  = params.get("event_id")
        event     = params.get("event") or {}

        # F38: in pool mode, wrap/rebuild Context with per-event values
        if self._pool_mode:
            ctx = Context(
                server_id=str(params.get("discord_srv_id") or ""),
                plugin_id=str(params.get("plugin_id") or self._ctx.plugin_id),
                version=str(params.get("version") or self._ctx.version),
                capabilities=list(params.get("capabilities") or []),
                transport=self._transport,
            )
        else:
            ctx = self._ctx

        # Set interaction ID on context for interaction events
        if event_type == "interaction_create" and event.get("interaction_id"):
            ctx._current_interaction_id = event["interaction_id"]
        else:
            ctx._current_interaction_id = None

        # F35: track whether all handlers succeeded
        all_ok = True
        handlers = self._event_handlers.get(event_type, [])
        for fn in handlers:
            try:
                fn(ctx, event)
            except Exception as e:
                all_ok = False
                try:
                    ctx.log(
                        f"Event handler error ({event_type}): {e}",
                        level="error",
                    )
                except Exception:
                    pass

        # Always ACK the event to prevent retry→DLQ loops.  Infrastructure
        # errors (DB FK violations, Discord 404s) are deterministic — retrying
        # the same event will fail identically.  The circuit breaker still
        # tracks failures via event.fail notification.
        if event_id is not None:
            if not all_ok:
                # Notify runner of failure for circuit breaker tracking
                try:
                    self._transport.notify("event.fail", {
                        "event_id": event_id,
                        "reason": "handler_exception",
                    })
                except Exception:
                    pass
            with self._ack_lock:
                self._ack_buffer.append(event_id)
                if len(self._ack_buffer) >= self._ACK_FLUSH_SIZE:
                    self._flush_ack_buffer_locked()

    def _flush_ack_buffer(self) -> None:
        """Send buffered event acks (thread-safe wrapper)."""
        with self._ack_lock:
            self._flush_ack_buffer_locked()

    def _flush_ack_buffer_locked(self) -> None:
        """Send buffered event acks. Must be called with _ack_lock held."""
        if not self._ack_buffer:
            return
        ids = list(self._ack_buffer)
        self._ack_buffer.clear()
        try:
            self._transport.notify("event.ack", {"event_ids": ids})
        except Exception as exc:
            try:
                self._transport.notify("plugin.log", {
                    "level": "error",
                    "message": f"_flush_ack_buffer failed ({len(ids)} events): {exc}",
                })
            except Exception:
                pass

    # ── Main run loop ──────────────────────────────────────────────────────

    def run(self) -> None:
        """
        Start the plugin.  This call blocks forever.

        Must be the last line of your __main__.py.
        """
        # Unbuffer stdout so JSON-RPC lines flush immediately
        sys.stdout = open(sys.stdout.fileno(), "w", buffering=1, closefd=False)  # noqa: WPS515

        # Ping the host so it knows we started cleanly
        self._transport.notify("plugin.log", {
            "level": "info",
            "message": "SDK plugin process started",
        })

        # Block reading stdin until the host closes it
        try:
            self._transport.read_loop()
        except KeyboardInterrupt:
            pass
